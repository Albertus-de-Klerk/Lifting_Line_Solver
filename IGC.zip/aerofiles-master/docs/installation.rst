.. _installation:

Installation
============

Given that you have a working python environment aerofiles is just one
single command away::

    $ pip install aerofiles

A few seconds later and you are good to go.
