License
=======

aerofiles is licensed under the MIT License.  The full license text can be
found below.

aerofiles License
-----------------

.. include:: ../LICENSE
