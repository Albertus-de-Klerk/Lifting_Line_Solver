:orphan:

Welcome to aerofiles
====================

Welcome to the aerofiles documentation.  This documentation is divided into
different parts.  You should start with :ref:`installation` and then head
over to the :ref:`api`.

.. include:: contents.rst.inc
