.. _api:

API Reference
=============

This part of the documentation covers all the public APIs of aerofiles.


.. toctree::
   :maxdepth: 2

   flarmcfg
   igc
   openair
   seeyou
   welt2000
   xcsoar
