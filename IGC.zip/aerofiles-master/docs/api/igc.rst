aerofiles.igc
=============

.. automodule:: aerofiles.igc

.. autoclass:: aerofiles.igc.Reader
   :members:
   :inherited-members:

.. autoclass:: aerofiles.igc.Writer
   :members:
   :inherited-members:
