aerofiles.openair
=================

.. autoclass:: aerofiles.openair.Reader
   :members:
   :inherited-members:

.. autoclass:: aerofiles.openair.LowLevelReader
   :members:
   :inherited-members:
