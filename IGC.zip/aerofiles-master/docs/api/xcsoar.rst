aerofiles.xcsoar
================

.. autoclass:: aerofiles.xcsoar.Writer
   :members:


.. automodule:: aerofiles.xcsoar.constants
   :members:
   :undoc-members:
