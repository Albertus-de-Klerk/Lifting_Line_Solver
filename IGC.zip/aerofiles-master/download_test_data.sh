#!/bin/sh
wget -NP tests/welt2000/data/ https://raw.githubusercontent.com/skylines-project/welt2000/master/WELT2000.TXT
